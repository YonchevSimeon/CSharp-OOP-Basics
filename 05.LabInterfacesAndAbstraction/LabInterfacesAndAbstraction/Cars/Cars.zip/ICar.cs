﻿public interface ICar
{
    string Model { get; set; }
    string Color { get; set; }
    string Start { get; set; }
    string Stop { get; set; }
}
