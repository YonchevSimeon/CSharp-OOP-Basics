﻿public enum Seasons
{
    Autumn = 1,
    Spring,
    Winter,
    Summer
}