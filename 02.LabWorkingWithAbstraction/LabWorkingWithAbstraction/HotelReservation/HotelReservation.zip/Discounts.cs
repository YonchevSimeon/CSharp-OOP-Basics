﻿public enum Discounts
{
    None,
    SecondVisit = 10,
    VIP = 20
}
