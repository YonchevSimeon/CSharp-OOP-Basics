﻿public interface IId
{
    string Id { get; set; }
}
