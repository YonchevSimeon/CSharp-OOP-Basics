﻿public interface IIdentity
{
    string Id { get; set; }
}
