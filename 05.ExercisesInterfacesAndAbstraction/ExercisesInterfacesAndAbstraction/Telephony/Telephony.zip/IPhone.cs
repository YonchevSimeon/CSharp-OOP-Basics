﻿public interface IPhone
{
    string Calling(string number);
}
