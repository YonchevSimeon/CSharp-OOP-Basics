﻿public interface IWWW
{
    string Browsing(string site);
}