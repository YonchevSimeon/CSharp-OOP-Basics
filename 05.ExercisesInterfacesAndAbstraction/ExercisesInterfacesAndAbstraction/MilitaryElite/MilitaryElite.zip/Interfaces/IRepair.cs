﻿public interface IRepair
{
    string PartName { get; set; }
    int WorkedHours { get; set; }
}
