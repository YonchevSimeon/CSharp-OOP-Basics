﻿public interface IMission
{
    string CodeName { get; set; }
    string State { get; set; }
}
