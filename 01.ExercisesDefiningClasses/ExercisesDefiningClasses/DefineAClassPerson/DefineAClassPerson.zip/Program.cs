﻿using System;

class Program
{
    static void Main(string[] args)
    {
        Person pesho = new Person() { Age = 20, Name = "Pesho" };
        Person gosho = new Person() { Age = 18, Name = "Gosho" };
        Person stamat = new Person() { Age = 43, Name = "Stamat" };
    }
}
