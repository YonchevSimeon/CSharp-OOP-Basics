﻿public class Animal
{
    public void Eat()
    {
        System.Console.WriteLine("eating...");
    }
}